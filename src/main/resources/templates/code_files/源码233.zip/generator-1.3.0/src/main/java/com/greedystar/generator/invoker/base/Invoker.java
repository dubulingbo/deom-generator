package com.greedystar.generator.invoker.base;

/**
 * Author GreedyStar
 * Date   2018-09-10
 */
public interface Invoker {

    public void execute();

}
